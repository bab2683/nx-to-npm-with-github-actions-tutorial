(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@babdev/test-publishable', ['exports', '@angular/core', '@angular/common'], factory) :
    (global = global || self, factory((global.babdev = global.babdev || {}, global.babdev['test-publishable'] = {}), global.ng.core, global.ng.common));
}(this, function (exports, core, common) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var TestPublishableModule = /** @class */ (function () {
        function TestPublishableModule() {
        }
        TestPublishableModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [common.CommonModule]
                    },] }
        ];
        return TestPublishableModule;
    }());
    console.log('it works');

    exports.TestPublishableModule = TestPublishableModule;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=babdev-test-publishable.umd.js.map
