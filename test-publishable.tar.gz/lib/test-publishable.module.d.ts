export declare class TestPublishableModule {
}
